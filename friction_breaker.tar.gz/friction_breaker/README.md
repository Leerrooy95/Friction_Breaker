# 🔧 Friction Breaker — Mechanism Classifier + Countermeasure Engine

**An open-source tool that identifies legal, regulatory, and procedural mechanisms used to bypass democratic accountability — and generates ranked countermeasures that citizens, legislators, and courts can implement.**

Powered by [The Regulated Friction Project](https://github.com/Leerrooy95/The_Regulated_Friction_Project).

---

## What It Does

1. **You paste text** — a news article, executive order, bill text, regulatory action, or anything else.
2. **GLiNER2 extracts entities** locally (zero-cost, no API needed, runs on CPU).
3. **The Mechanism Classifier** matches what it finds against a taxonomy of 33+ documented mechanisms extracted from The Regulated Friction Project.
4. **Claude generates countermeasure analysis** — ranked by durability (hardest to remove first) — in plain English anyone can understand.

No data is stored. Your API key goes directly to Anthropic. This tool is open source.

---

## Quick Start

```bash
# Clone
git clone https://github.com/YOUR_USERNAME/friction_breaker.git
cd friction_breaker

# Install dependencies
pip install -r requirements.txt

# Set your API key
cp .env.example .env
# Edit .env → add your ANTHROPIC_API_KEY

# Run
python app.py
# Open http://localhost:5000
```

### CLI Mode

```bash
# Analyze text directly
python app.py --analyze "The Arkansas PSC approved Entergy's application despite finding the cost not reasonable..."

# Analyze a URL
python app.py --url "https://example.com/article-about-new-regulation"
```

### On DigitalOcean Droplet

```bash
# Run on port 80 (requires root or port forwarding)
python app.py --port 80

# Or use a reverse proxy (nginx) pointing to port 5000
python app.py --port 5000
```

---

## BYOK (Bring Your Own Key)

This tool requires an **Anthropic API key** for the countermeasure analysis step. You can:

1. Enter it in the web interface (stays in your browser, sent directly to Anthropic)
2. Set it in `.env` as `ANTHROPIC_API_KEY=sk-ant-...`
3. Export it: `export ANTHROPIC_API_KEY=sk-ant-...`

GLiNER2 runs locally — no API key needed for entity extraction.

---

## Stack

| Component | What It Does | Cost |
|-----------|-------------|------|
| **GLiNER2** | Local entity extraction (205M params, CPU) | Free |
| **Claude API** | Mechanism classification + countermeasure analysis | BYOK — user pays their own usage |
| **Flask** | Web interface | Free |
| **Mechanism Taxonomy** | 33+ mechanisms from The Regulated Friction Project | Free |

**No Brave API. No external search APIs.** The tool works entirely on user-provided text + local entity extraction + Claude analysis.

---

## File Structure

```
friction_breaker/
├── app.py                              # Flask app + CLI + analysis pipeline
├── mechanism_classifier_taxonomy.json  # The taxonomy (33+ mechanisms, 8 categories)
├── MECHANISM_CLASSIFIER_README.md      # Taxonomy documentation
├── templates/
│   └── index.html                      # Web UI
├── _AI_CONTEXT_INDEX/                  # Background knowledge (sync from main repo)
├── output/                             # Analysis results (auto-created)
├── requirements.txt                    # Python dependencies
├── .env.example                        # API key template
└── README.md                           # This file
```

---

## Syncing the Knowledge Base

The `_AI_CONTEXT_INDEX/` directory should contain markdown files from [The Regulated Friction Project](https://github.com/Leerrooy95/The_Regulated_Friction_Project). To sync:

```bash
# One-time clone
git clone https://github.com/Leerrooy95/The_Regulated_Friction_Project.git /tmp/rfp

# Copy context files
cp /tmp/rfp/_AI_CONTEXT_INDEX/*.md _AI_CONTEXT_INDEX/
```

Or set up a cron job / GitHub Action to sync periodically.

---

## How The Taxonomy Works

Each mechanism in the taxonomy has:

- **ID** — Unique identifier (e.g., A-01)
- **Category** — Legislative Architecture, Regulatory Capture, Personnel Cycling, etc.
- **Durability Score** — 1-10 (how hard it is to reverse)
- **Reversal Pathways** — Specific countermeasures ranked by durability
- **Real Examples** — Verified instances from the research

See `MECHANISM_CLASSIFIER_README.md` for full documentation.

---

## Contributing

This is open source. If you identify a mechanism that isn't in the taxonomy:

1. Document it with sources
2. Add it to `mechanism_classifier_taxonomy.json`
3. Submit a PR

The tool itself will flag new mechanisms it detects that aren't in the taxonomy (`new_mechanisms_detected` in the output).

---

## License

Same as [The Regulated Friction Project](https://github.com/Leerrooy95/The_Regulated_Friction_Project).

Built by [Austin Smith](https://github.com/Leerrooy95) · Leroy's Web Development
