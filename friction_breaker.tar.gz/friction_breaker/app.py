"""
app.py — Friction Breaker: Mechanism Classifier + Countermeasure Engine
========================================================================
BYOK Flask application that takes user-provided text (news articles,
executive orders, legislative text, regulatory actions), extracts
entities via GLiNER2 (local, zero-cost), classifies mechanisms against
the taxonomy, and generates countermeasure analysis via Anthropic Claude.

Usage:
    python app.py                          # Start Flask server (port 5000)
    python app.py --port 8080              # Custom port
    python app.py --analyze "text here"    # CLI mode, skip Flask

Requires: ANTHROPIC_API_KEY in .env or environment.
"""

import argparse
import json
import logging
import os
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
logger = logging.getLogger(__name__)

# ─── Dependency checks ────────────────────────────────────────────────────────
try:
    from flask import Flask, render_template, request, jsonify, session
    _HAS_FLASK = True
except ImportError:
    _HAS_FLASK = False
    logger.warning("Flask not installed. CLI mode only. Run: pip install flask")

try:
    import anthropic
    _HAS_ANTHROPIC = True
except ImportError:
    _HAS_ANTHROPIC = False
    logger.error("anthropic package not installed. Run: pip install anthropic")

try:
    import requests as req_lib
    _HAS_REQUESTS = True
except ImportError:
    _HAS_REQUESTS = False
    logger.warning("requests not installed. URL fetching disabled.")

# ─── GLiNER2 (local, zero-cost entity extraction) ────────────────────────────
_HAS_GLINER = False
_gliner_model = None

def _load_gliner():
    """Lazy-load GLiNER2 model (first call only)."""
    global _HAS_GLINER, _gliner_model
    if _gliner_model is not None:
        return _gliner_model
    try:
        from gliner import GLiNER
        logger.info("Loading GLiNER model (first run downloads ~400MB)...")
        _gliner_model = GLiNER.from_pretrained("urchade/gliner_multi-v2.1")
        _HAS_GLINER = True
        logger.info("GLiNER model loaded.")
        return _gliner_model
    except ImportError:
        logger.warning("GLiNER not installed. Entity extraction will use Claude only.")
        return None
    except Exception as e:
        logger.warning(f"GLiNER load failed: {e}. Entity extraction will use Claude only.")
        return None


# ─── CONFIG ───────────────────────────────────────────────────────────────────
_ANTHROPIC_MODEL = "claude-sonnet-4-20250514"
_MAX_INPUT_CHARS = 50000
_TAXONOMY_FILE = Path("mechanism_classifier_taxonomy.json")
_CONTEXT_DIR = Path("_AI_CONTEXT_INDEX")
_OUTPUT_DIR = Path("output")

# Entity labels for GLiNER2 — tuned for mechanism detection
_GLINER_LABELS = [
    "legislation", "law", "act", "bill", "statute", "regulation",
    "executive order", "policy", "rule", "amendment",
    "person", "politician", "official", "judge",
    "organization", "agency", "department", "committee", "fund",
    "company", "corporation", "shell company",
    "jurisdiction", "state", "country",
    "court case", "lawsuit", "ruling", "injunction",
    "financial instrument", "stablecoin", "cryptocurrency",
    "mechanism", "procedure", "exemption", "designation",
    "tax incentive", "abatement", "rider", "charter",
]

# ─── Load taxonomy ────────────────────────────────────────────────────────────
def load_taxonomy() -> dict:
    """Load the mechanism classifier taxonomy."""
    if not _TAXONOMY_FILE.exists():
        logger.error(f"Taxonomy file not found: {_TAXONOMY_FILE}")
        return {"mechanisms": [], "categories": []}
    with open(_TAXONOMY_FILE) as f:
        return json.load(f)


def load_context_index() -> str:
    """Load all markdown files from _AI_CONTEXT_INDEX into a single string."""
    if not _CONTEXT_DIR.exists():
        return ""
    parts = []
    for md_file in sorted(_CONTEXT_DIR.glob("*.md")):
        try:
            content = md_file.read_text(errors="replace")
            # Truncate individual files to keep total context manageable
            if len(content) > 8000:
                content = content[:8000] + "\n\n[... truncated for context window ...]"
            parts.append(f"## {md_file.name}\n\n{content}")
        except Exception as e:
            logger.warning(f"Could not read {md_file}: {e}")
    combined = "\n\n---\n\n".join(parts)
    # Hard cap on total context
    if len(combined) > 60000:
        combined = combined[:60000] + "\n\n[... truncated ...]"
    return combined


# ─── GLiNER2 entity extraction ────────────────────────────────────────────────
def extract_entities_gliner(text: str) -> list[dict]:
    """Extract entities from text using GLiNER2 (local, zero-cost)."""
    model = _load_gliner()
    if model is None:
        return []

    # GLiNER works best on chunks < 1000 chars
    chunks = _chunk_text(text, max_chars=900)
    all_entities = []
    seen = set()

    for chunk in chunks:
        try:
            entities = model.predict_entities(chunk, _GLINER_LABELS, threshold=0.4)
            for ent in entities:
                key = (ent["text"].lower().strip(), ent["label"])
                if key not in seen:
                    seen.add(key)
                    all_entities.append({
                        "text": ent["text"].strip(),
                        "label": ent["label"],
                        "score": round(ent["score"], 3)
                    })
        except Exception as e:
            logger.warning(f"GLiNER extraction error on chunk: {e}")

    # Sort by confidence
    all_entities.sort(key=lambda x: x["score"], reverse=True)
    return all_entities


def _chunk_text(text: str, max_chars: int = 900) -> list[str]:
    """Split text into chunks at sentence boundaries."""
    sentences = text.replace("\n", " ").split(". ")
    chunks = []
    current = ""
    for sent in sentences:
        if len(current) + len(sent) + 2 > max_chars:
            if current:
                chunks.append(current.strip())
            current = sent + ". "
        else:
            current += sent + ". "
    if current.strip():
        chunks.append(current.strip())
    return chunks if chunks else [text[:max_chars]]


# ─── Claude API: Mechanism Classification + Countermeasure Analysis ──────────
def analyze_with_claude(
    text: str,
    entities: list[dict],
    taxonomy: dict,
    context_index: str,
    api_key: str
) -> dict:
    """
    Send text + extracted entities + taxonomy to Claude for:
    1. Mechanism classification (which taxonomy entries match)
    2. Countermeasure analysis (ranked by durability)
    3. Plain-English explanation (Political Translator format)
    """
    if not _HAS_ANTHROPIC:
        return {"error": "anthropic package not installed"}

    client = anthropic.Anthropic(api_key=api_key)

    # Build taxonomy summary for the prompt
    taxonomy_summary = json.dumps([
        {
            "id": m["id"],
            "name": m["name"],
            "category": m["category"],
            "description": m["description"],
            "durability": m["durability"],
            "reversal_pathways": m["reversal_pathways"]
        }
        for m in taxonomy.get("mechanisms", [])
    ], indent=1)

    entity_summary = json.dumps(entities[:30], indent=1) if entities else "No entities extracted."

    # Truncate input text for prompt
    input_text = text[:12000] if len(text) > 12000 else text

    prompt = f"""You are the Friction Breaker — a countermeasure analysis engine.

You have two knowledge sources:
1. A MECHANISM CLASSIFIER TAXONOMY — a structured database of every legal, regulatory, personnel, financial, and procedural mechanism documented in The Regulated Friction Project.
2. A BACKGROUND KNOWLEDGE BASE — research context from the _AI_CONTEXT_INDEX.

Your job:
1. Read the user's input text.
2. Identify which mechanisms from the taxonomy are being deployed, referenced, or enabled.
3. For each identified mechanism, retrieve its reversal pathways.
4. Generate a COUNTERMEASURE REPORT in plain English that anyone can understand.

## MECHANISM TAXONOMY
{taxonomy_summary}

## EXTRACTED ENTITIES (from GLiNER2, local extraction)
{entity_summary}

## USER INPUT TEXT
{input_text}

## OUTPUT FORMAT

Respond with a JSON object containing:
{{
  "timestamp": "ISO 8601",
  "input_summary": "2-3 sentence summary of what the user submitted",
  "mechanisms_identified": [
    {{
      "taxonomy_id": "A-01",
      "name": "Mechanism name from taxonomy",
      "confidence": "HIGH / MEDIUM / LOW",
      "evidence": "Quote or reference from the input text that triggered this match",
      "what_it_does": "1-2 sentence plain-English explanation of what this mechanism does to citizens",
      "durability": 6,
      "countermeasures": [
        {{
          "action": "Specific countermeasure from reversal_pathways",
          "durability_score": 7,
          "feasibility": "HIGH / MEDIUM / LOW",
          "who_can_do_it": "Who has the power to implement this (citizens, state legislature, Congress, courts, etc.)",
          "plain_english": "What this means in everyday language"
        }}
      ]
    }}
  ],
  "new_mechanisms_detected": [
    {{
      "name": "If you identify a mechanism NOT in the taxonomy",
      "description": "What it does",
      "suggested_category": "A-H",
      "suggested_durability": 5,
      "why_it_matters": "Plain English"
    }}
  ],
  "political_translator_summary": "A 3-5 paragraph summary written at an 8th-grade reading level explaining what was found, what it means for ordinary people, and what can be done about it. Use the same style as the DAILY_REPORTS Political Translator: short sentences, define technical terms inline, be specific about costs and impacts."
}}

IMPORTANT:
- Respond ONLY with the JSON object. No markdown fences. No preamble.
- Every countermeasure must specify WHO can implement it.
- Rank countermeasures by durability (hardest to remove first).
- If no mechanisms match, say so honestly — don't force matches.
- If you detect a mechanism NOT in the taxonomy, add it to new_mechanisms_detected.
"""

    try:
        response = client.messages.create(
            model=_ANTHROPIC_MODEL,
            max_tokens=8000,
            messages=[{"role": "user", "content": prompt}]
        )
        raw = response.content[0].text.strip()

        # Clean potential markdown fences
        if raw.startswith("```"):
            raw = raw.split("\n", 1)[1] if "\n" in raw else raw[3:]
        if raw.endswith("```"):
            raw = raw[:-3]
        raw = raw.strip()
        if raw.startswith("json"):
            raw = raw[4:].strip()

        result = json.loads(raw)
        return result

    except json.JSONDecodeError as e:
        logger.error(f"Claude returned invalid JSON: {e}")
        return {"error": f"Invalid JSON from Claude: {str(e)}", "raw_response": raw[:2000]}
    except anthropic.AuthenticationError:
        return {"error": "Invalid API key. Check your ANTHROPIC_API_KEY."}
    except anthropic.RateLimitError:
        return {"error": "Rate limited. Wait a moment and try again."}
    except Exception as e:
        return {"error": f"Claude API error: {str(e)}"}


# ─── URL fetching ─────────────────────────────────────────────────────────────
def fetch_url(url: str) -> str:
    """Fetch text content from a URL."""
    if not _HAS_REQUESTS:
        return ""
    try:
        resp = req_lib.get(url, timeout=15, headers={
            "User-Agent": "FrictionBreaker/1.0 (OSINT research tool)"
        })
        resp.raise_for_status()
        # Basic HTML stripping — just get readable text
        text = resp.text
        # Remove script/style blocks
        import re
        text = re.sub(r'<script[^>]*>.*?</script>', '', text, flags=re.DOTALL)
        text = re.sub(r'<style[^>]*>.*?</style>', '', text, flags=re.DOTALL)
        text = re.sub(r'<[^>]+>', ' ', text)
        text = re.sub(r'\s+', ' ', text).strip()
        return text[:_MAX_INPUT_CHARS]
    except Exception as e:
        logger.warning(f"URL fetch failed: {e}")
        return ""


# ─── Save results ─────────────────────────────────────────────────────────────
def save_result(result: dict) -> Path:
    """Save analysis result to output/ directory."""
    _OUTPUT_DIR.mkdir(exist_ok=True)
    ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    filepath = _OUTPUT_DIR / f"analysis_{ts}.json"
    with open(filepath, "w") as f:
        json.dump(result, f, indent=2)
    logger.info(f"Result saved: {filepath}")
    return filepath


# ─── Full analysis pipeline ───────────────────────────────────────────────────
def run_analysis(text: str, api_key: str) -> dict:
    """Run the full Friction Breaker pipeline on input text."""
    start = time.time()

    # 1. Load taxonomy
    taxonomy = load_taxonomy()
    if not taxonomy.get("mechanisms"):
        return {"error": "Taxonomy not loaded. Ensure mechanism_classifier_taxonomy.json exists."}

    # 2. Load context index
    context_index = load_context_index()

    # 3. Extract entities (GLiNER2, local, zero-cost)
    logger.info("Extracting entities with GLiNER2...")
    entities = extract_entities_gliner(text)
    logger.info(f"Extracted {len(entities)} entities.")

    # 4. Classify and analyze (Claude API)
    logger.info("Sending to Claude for mechanism classification + countermeasure analysis...")
    result = analyze_with_claude(text, entities, taxonomy, context_index, api_key)

    # 5. Add metadata
    result["_meta"] = {
        "gliner_entities_extracted": len(entities),
        "gliner_entities": entities[:20],
        "taxonomy_mechanisms_available": len(taxonomy.get("mechanisms", [])),
        "context_index_loaded": bool(context_index),
        "processing_time_seconds": round(time.time() - start, 2),
        "model": _ANTHROPIC_MODEL,
        "timestamp": datetime.now(timezone.utc).isoformat()
    }

    # 6. Save
    save_result(result)

    return result


# ─── Flask App ────────────────────────────────────────────────────────────────
def create_app():
    app = Flask(__name__)
    app.secret_key = os.urandom(24)

    @app.route("/")
    def index():
        return render_template("index.html")

    @app.route("/analyze", methods=["POST"])
    def analyze():
        data = request.get_json()
        if not data:
            return jsonify({"error": "No JSON body"}), 400

        api_key = data.get("api_key", "").strip()
        text = data.get("text", "").strip()
        url = data.get("url", "").strip()

        if not api_key:
            # Fall back to env var
            api_key = os.getenv("ANTHROPIC_API_KEY", "")
        if not api_key:
            return jsonify({"error": "No API key provided. Set ANTHROPIC_API_KEY or enter it in the form."}), 400

        # Get text from URL if provided
        if url and not text:
            text = fetch_url(url)
            if not text:
                return jsonify({"error": f"Could not fetch content from URL: {url}"}), 400

        if not text:
            return jsonify({"error": "No text provided. Paste text or provide a URL."}), 400

        if len(text) > _MAX_INPUT_CHARS:
            text = text[:_MAX_INPUT_CHARS]

        result = run_analysis(text, api_key)
        return jsonify(result)

    @app.route("/taxonomy")
    def taxonomy_view():
        taxonomy = load_taxonomy()
        return jsonify(taxonomy)

    @app.route("/health")
    def health():
        return jsonify({
            "status": "ok",
            "gliner_available": _HAS_GLINER or _load_gliner() is not None,
            "anthropic_available": _HAS_ANTHROPIC,
            "taxonomy_loaded": _TAXONOMY_FILE.exists(),
            "context_index_loaded": _CONTEXT_DIR.exists()
        })

    return app


# ─── CLI Mode ─────────────────────────────────────────────────────────────────
def cli_analyze(text: str):
    """Run analysis from command line."""
    api_key = os.getenv("ANTHROPIC_API_KEY", "")
    if not api_key:
        logger.error("ANTHROPIC_API_KEY not set. Add it to .env or export it.")
        sys.exit(1)
    result = run_analysis(text, api_key)
    print(json.dumps(result, indent=2))


# ─── Main ─────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Friction Breaker — Countermeasure Engine")
    parser.add_argument("--port", type=int, default=5000, help="Flask server port")
    parser.add_argument("--analyze", type=str, help="Analyze text directly (CLI mode)")
    parser.add_argument("--url", type=str, help="Fetch and analyze a URL (CLI mode)")
    args = parser.parse_args()

    if args.analyze:
        cli_analyze(args.analyze)
    elif args.url:
        text = fetch_url(args.url)
        if text:
            cli_analyze(text)
        else:
            logger.error(f"Could not fetch URL: {args.url}")
    else:
        if not _HAS_FLASK:
            logger.error("Flask not installed. Install it: pip install flask")
            sys.exit(1)
        app = create_app()
        print(f"\n🔧 Friction Breaker running on http://localhost:{args.port}")
        print(f"   Taxonomy: {len(load_taxonomy().get('mechanisms', []))} mechanisms loaded")
        print(f"   GLiNER2: {'available' if _load_gliner() else 'not available (Claude-only mode)'}")
        print(f"   BYOK: Enter your ANTHROPIC_API_KEY in the web interface\n")
        app.run(host="0.0.0.0", port=args.port, debug=False)
