"""
app.py — Friction Breaker: Mechanism Classifier + Countermeasure Engine
========================================================================
BYOK Flask application that takes user-provided text (news articles,
executive orders, legislative text, regulatory actions), extracts
entities via GLiNER2 (local, zero-cost), classifies mechanisms against
the taxonomy, and generates countermeasure analysis via Anthropic Claude.

Usage:
    python app.py                          # Start Flask server (port 5000)
    python app.py --port 8080              # Custom port
    python app.py --analyze "text here"    # CLI mode, skip Flask

Requires: ANTHROPIC_API_KEY in .env or environment.
"""

import argparse
import csv
import io
import ipaddress
import json
import logging
import os
import re
import socket
import sys
import threading
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import quote as urlquote
from urllib.parse import urlparse

from dotenv import load_dotenv

load_dotenv()

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
logger = logging.getLogger(__name__)


def _sanitize_for_log(msg: object) -> str:
    """Strip newline characters from log messages to prevent log injection (CWE-117).

    Any carriage-return or newline in user-controlled data would allow an
    attacker to forge additional log entries.  Replace them with a space.
    """
    return str(msg).replace("\r\n", " ").replace("\r", " ").replace("\n", " ")


# ─── Dependency checks ────────────────────────────────────────────────────────
try:
    from flask import Flask, jsonify, make_response, render_template, request
    _HAS_FLASK = True
except ImportError:
    _HAS_FLASK = False
    logger.warning("Flask not installed. CLI mode only. Run: pip install flask")

try:
    from flask_limiter import Limiter
    from flask_limiter.util import get_remote_address
    _HAS_LIMITER = True
except ImportError:
    _HAS_LIMITER = False

try:
    import anthropic
    _HAS_ANTHROPIC = True
except ImportError:
    _HAS_ANTHROPIC = False
    logger.error("anthropic package not installed. Run: pip install anthropic")

try:
    import requests as req_lib
    _HAS_REQUESTS = True
except ImportError:
    _HAS_REQUESTS = False
    logger.warning("requests not installed. URL fetching disabled.")

try:
    from docx import Document as DocxDocument
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.shared import Pt, RGBColor
    _HAS_DOCX = True
except ImportError:
    _HAS_DOCX = False
    logger.warning("python-docx not installed. DOCX export disabled.")

try:
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
    from reportlab.lib.units import inch
    from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer
    _HAS_REPORTLAB = True
except ImportError:
    _HAS_REPORTLAB = False
    logger.warning("reportlab not installed. PDF export disabled.")

# ─── GLiNER2 (local, zero-cost entity extraction) ────────────────────────────
_HAS_GLINER = False
_gliner_model = None

def _load_gliner():
    """Lazy-load GLiNER2 model (first call only)."""
    global _HAS_GLINER, _gliner_model
    if _gliner_model is not None:
        return _gliner_model
    try:
        from gliner import GLiNER
        logger.info("Loading GLiNER model (first run downloads ~400MB)...")
        _gliner_model = GLiNER.from_pretrained("urchade/gliner_multi-v2.1")
        _HAS_GLINER = True
        logger.info("GLiNER model loaded.")
        return _gliner_model
    except ImportError:
        logger.warning("GLiNER not installed. Entity extraction will use Claude only.")
        return None
    except Exception as e:
        logger.warning(f"GLiNER load failed: {_sanitize_for_log(e)}. Entity extraction will use Claude only.")
        return None


# ─── CONFIG ───────────────────────────────────────────────────────────────────
_ANTHROPIC_MODEL = os.getenv("ANTHROPIC_MODEL", "claude-sonnet-4-6")
_RATE_LIMIT = os.getenv("RATE_LIMIT", "10 per minute")
_FLASK_HOST = os.getenv("FLASK_HOST", "127.0.0.1")  # Bind to loopback by default (CWE-605)
_MAX_INPUT_CHARS = 50000
_MAX_CONTEXT_CHARS = 8000  # Cap for context index injected into Claude prompt
_BASE_DIR = Path(__file__).resolve().parent
_TAXONOMY_FILE = _BASE_DIR / "mechanism_classifier_taxonomy.json"
_CONTEXT_DIR = _BASE_DIR / "_AI_CONTEXT_INDEX"
_OUTPUT_DIR = _BASE_DIR / "output"

# ─── Async job queue (avoids proxy/CDN 60-second timeout) ────────────────────
_jobs: dict = {}
_jobs_lock = threading.Lock()
_JOB_TTL_SECONDS = 1800  # Expire completed jobs after 30 minutes


def _cleanup_old_jobs() -> None:
    """Remove completed/errored jobs older than _JOB_TTL_SECONDS."""
    cutoff = time.time() - _JOB_TTL_SECONDS
    with _jobs_lock:
        expired = [jid for jid, job in _jobs.items() if job.get("created_at", 0) < cutoff]
        for jid in expired:
            del _jobs[jid]


def _run_job_thread(job_id: str, text: str, api_key: str) -> None:
    """Worker thread: run the analysis pipeline and store the result."""
    with _jobs_lock:
        if job_id in _jobs:
            _jobs[job_id]["status"] = "running"
    try:
        result = run_analysis(text, api_key)
        with _jobs_lock:
            if job_id in _jobs:
                _jobs[job_id].update({"status": "done", "result": result})
    except Exception as exc:
        logger.error(f"Job {job_id} failed: {_sanitize_for_log(exc)}")
        with _jobs_lock:
            if job_id in _jobs:
                _jobs[job_id].update({
                    "status": "error",
                    "result": {"error": "Analysis failed unexpectedly. Please try again."},
                })

# ─── Cached data (loaded once, reused across requests) ───────────────────────
_cached_taxonomy: dict | None = None
_cached_context_index: str | None = None

# Entity labels for GLiNER2 — tuned for mechanism detection
_GLINER_LABELS = [
    "legislation", "law", "act", "bill", "statute", "regulation",
    "executive order", "policy", "rule", "amendment",
    "person", "politician", "official", "judge",
    "organization", "agency", "department", "committee", "fund",
    "company", "corporation", "shell company",
    "jurisdiction", "state", "country",
    "court case", "lawsuit", "ruling", "injunction",
    "financial instrument", "stablecoin", "cryptocurrency",
    "mechanism", "procedure", "exemption", "designation",
    "tax incentive", "abatement", "rider", "charter",
]

# ─── Load taxonomy ────────────────────────────────────────────────────────────
def load_taxonomy() -> dict:
    """Load the mechanism classifier taxonomy (cached after first call)."""
    global _cached_taxonomy
    if _cached_taxonomy is not None:
        return _cached_taxonomy
    if not _TAXONOMY_FILE.exists():
        logger.error(f"Taxonomy file not found: {_TAXONOMY_FILE}")
        return {"mechanisms": [], "categories": []}
    with open(_TAXONOMY_FILE) as f:
        _cached_taxonomy = json.load(f)
    return _cached_taxonomy


def load_context_index() -> str:
    """Load all markdown files from _AI_CONTEXT_INDEX into a single string (cached after first call)."""
    global _cached_context_index
    if _cached_context_index is not None:
        return _cached_context_index
    if not _CONTEXT_DIR.exists():
        return ""
    parts = []
    for md_file in sorted(_CONTEXT_DIR.rglob("*.md")):
        try:
            content = md_file.read_text(errors="replace")
            # Truncate individual files to keep total context manageable
            if len(content) > 8000:
                content = content[:8000] + "\n\n[... truncated for context window ...]"
            parts.append(f"## {md_file.name}\n\n{content}")
        except Exception as e:
            logger.warning(f"Could not read {md_file}: {e}")
    combined = "\n\n---\n\n".join(parts)
    # Hard cap on total context
    if len(combined) > 60000:
        combined = combined[:60000] + "\n\n[... truncated ...]"
    _cached_context_index = combined
    return _cached_context_index


# ─── GLiNER2 entity extraction ────────────────────────────────────────────────
def extract_entities_gliner(text: str) -> list[dict]:
    """Extract entities from text using GLiNER2 (local, zero-cost)."""
    model = _load_gliner()
    if model is None:
        return []

    # GLiNER works best on chunks < 1000 chars
    chunks = _chunk_text(text, max_chars=900)
    all_entities = []
    seen = set()

    for chunk in chunks:
        try:
            entities = model.predict_entities(chunk, _GLINER_LABELS, threshold=0.4)
            for ent in entities:
                key = (ent["text"].lower().strip(), ent["label"])
                if key not in seen:
                    seen.add(key)
                    all_entities.append({
                        "text": ent["text"].strip(),
                        "label": ent["label"],
                        "score": round(ent["score"], 3)
                    })
        except Exception as e:
            logger.warning(f"GLiNER extraction error on chunk: {_sanitize_for_log(e)}")

    # Sort by confidence
    all_entities.sort(key=lambda x: x["score"], reverse=True)
    return all_entities


def _chunk_text(text: str, max_chars: int = 900) -> list[str]:
    """Split text into chunks at sentence boundaries."""
    sentences = text.replace("\n", " ").split(". ")
    chunks = []
    current = ""
    for sent in sentences:
        if len(current) + len(sent) + 2 > max_chars:
            if current:
                chunks.append(current.strip())
            current = sent + ". "
        else:
            current += sent + ". "
    if current.strip():
        chunks.append(current.strip())
    return chunks if chunks else [text[:max_chars]]


# ─── Claude API: Mechanism Classification + Countermeasure Analysis ──────────
def analyze_with_claude(
    text: str,
    entities: list[dict],
    taxonomy: dict,
    context_index: str,
    api_key: str
) -> dict:
    """
    Send text + extracted entities + taxonomy to Claude for:
    1. Mechanism classification (which taxonomy entries match)
    2. Countermeasure analysis (ranked by durability)
    3. Plain-English explanation (Political Translator format)
    """
    if not _HAS_ANTHROPIC:
        return {"error": "anthropic package not installed"}

    client = anthropic.Anthropic(api_key=api_key)

    # Build taxonomy summary for the prompt
    taxonomy_summary = json.dumps([
        {
            "id": m["id"],
            "name": m["name"],
            "category": m["category"],
            "description": m["description"],
            "durability": m["durability"],
            "reversal_pathways": m["reversal_pathways"]
        }
        for m in taxonomy.get("mechanisms", [])
    ], indent=1)

    entity_summary = json.dumps(entities[:30], indent=1) if entities else "No entities extracted."

    # Truncate input text for prompt
    input_text = text[:12000] if len(text) > 12000 else text

    # Include context index (capped to _MAX_CONTEXT_CHARS to manage token usage).
    # This gives Claude background research from The Regulated Friction Project
    # to improve mechanism identification and countermeasure quality.
    context_snippet = ""
    if context_index:
        context_snippet = context_index[:_MAX_CONTEXT_CHARS]
        if len(context_index) > _MAX_CONTEXT_CHARS:
            context_snippet += "\n\n[... truncated for context window ...]"

    prompt = f"""You are the Friction Breaker — a countermeasure analysis engine.

You have two knowledge sources:
1. A MECHANISM CLASSIFIER TAXONOMY — a structured database of every legal, regulatory, personnel, financial, and procedural mechanism documented in The Regulated Friction Project.
2. A BACKGROUND KNOWLEDGE BASE — research context from the _AI_CONTEXT_INDEX.

Your job:
1. Read the user's input text.
2. Identify which mechanisms from the taxonomy are being deployed, referenced, or enabled.
3. For each identified mechanism, retrieve its reversal pathways.
4. Generate a COUNTERMEASURE REPORT in plain English that anyone can understand.

## MECHANISM TAXONOMY
{taxonomy_summary}

## BACKGROUND KNOWLEDGE BASE
{context_snippet if context_snippet else "No background context available."}

## EXTRACTED ENTITIES (from GLiNER2, local extraction)
{entity_summary}

## USER INPUT TEXT
{input_text}

## OUTPUT FORMAT

Respond with a JSON object containing:
{{
  "timestamp": "ISO 8601",
  "input_summary": "2-3 sentence summary of what the user submitted",
  "mechanisms_identified": [
    {{
      "taxonomy_id": "A-01",
      "name": "Mechanism name from taxonomy",
      "confidence": "HIGH / MEDIUM / LOW",
      "evidence": "Quote or reference from the input text that triggered this match",
      "what_it_does": "1-2 sentence plain-English explanation of what this mechanism does to citizens",
      "durability": 6,
      "countermeasures": [
        {{
          "action": "Specific countermeasure from reversal_pathways",
          "durability_score": 7,
          "feasibility": "HIGH / MEDIUM / LOW",
          "who_can_do_it": "Who has the power to implement this (citizens, state legislature, Congress, courts, etc.)",
          "plain_english": "What this means in everyday language"
        }}
      ]
    }}
  ],
  "new_mechanisms_detected": [
    {{
      "name": "If you identify a mechanism NOT in the taxonomy",
      "description": "What it does",
      "suggested_category": "A-H",
      "suggested_durability": 5,
      "why_it_matters": "Plain English"
    }}
  ],
  "political_translator_summary": "A 3-5 paragraph summary written at an 8th-grade reading level explaining what was found, what it means for ordinary people, and what can be done about it. Use the same style as the DAILY_REPORTS Political Translator: short sentences, define technical terms inline, be specific about costs and impacts."
}}

IMPORTANT:
- Respond ONLY with the JSON object. No markdown fences. No preamble.
- Every countermeasure must specify WHO can implement it.
- Rank countermeasures by durability (hardest to remove first).
- If no mechanisms match, say so honestly — don't force matches.
- If you detect a mechanism NOT in the taxonomy, add it to new_mechanisms_detected.
"""

    try:
        response = client.messages.create(
            model=_ANTHROPIC_MODEL,
            max_tokens=8192,
            messages=[{"role": "user", "content": prompt}]
        )

        # Extract text from response content blocks.
        # claude-sonnet-4-6 uses adaptive thinking by default, so the
        # response may contain ThinkingBlock(s) before the TextBlock.
        # We iterate to find the first TextBlock instead of assuming
        # response.content[0] is always a TextBlock.
        raw = next((block.text.strip() for block in response.content if block.type == "text"), "")

        if not raw:
            logger.error("Claude response contained no text block")
            return {"error": "Claude returned an empty response. Please try again."}

        # Clean potential markdown fences
        if raw.startswith("```"):
            raw = raw.split("\n", 1)[1] if "\n" in raw else raw[3:]
        if raw.endswith("```"):
            raw = raw[:-3]
        raw = raw.strip()
        if raw.startswith("json"):
            raw = raw[4:].strip()

        result = json.loads(raw)
        return result

    except json.JSONDecodeError as e:
        logger.error(f"Claude returned invalid JSON: {e}")
        logger.debug(f"Raw response: {raw[:500]}")
        return {"error": "Claude returned an invalid response. Please try again."}
    except anthropic.AuthenticationError:
        return {"error": "Invalid API key. Check your ANTHROPIC_API_KEY."}
    except anthropic.RateLimitError:
        return {"error": "Rate limited. Wait a moment and try again."}
    except anthropic.BadRequestError as e:
        logger.error(f"Claude API bad request: {_sanitize_for_log(e)}")
        return {"error": f"Claude API error: {e.message}"}
    except Exception as e:
        logger.error(f"Claude API error: {_sanitize_for_log(e)}")
        return {"error": "An error occurred during analysis. Please try again."}


# ─── URL fetching ─────────────────────────────────────────────────────────────
_BLOCKED_HOSTS = {"localhost", "127.0.0.1", "0.0.0.0", "::1", "metadata.google.internal", "169.254.169.254"}

_RE_WHITESPACE = re.compile(r"\s+")

# Serialises all outbound URL fetches so the temporary socket.getaddrinfo
# override in _make_pinned_request() never races with another thread.
_dns_pin_lock = threading.Lock()


def _is_private_host(hostname: str) -> bool:
    """Check if a hostname resolves to a private/internal address."""
    if hostname in _BLOCKED_HOSTS:
        return True
    if hostname.endswith(".local"):
        return True
    # Block common private IP ranges by prefix (fast path before DNS lookup)
    for prefix in ("10.", "192.168.", "172.16.", "172.17.", "172.18.", "172.19.",
                    "172.20.", "172.21.", "172.22.", "172.23.", "172.24.", "172.25.",
                    "172.26.", "172.27.", "172.28.", "172.29.", "172.30.", "172.31."):
        if hostname.startswith(prefix):
            return True
    # Resolve DNS and check ALL returned IPs (prevents DNS rebinding via
    # split-horizon or short-TTL trickery at the initial validation stage)
    try:
        addr_info = socket.getaddrinfo(hostname, None, socket.AF_UNSPEC, socket.SOCK_STREAM)
        for _family, _type, _proto, _canonname, sockaddr in addr_info:
            ip = ipaddress.ip_address(sockaddr[0])
            if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved or ip.is_multicast:
                return True
    except (socket.gaierror, ValueError):
        pass
    return False


def _resolve_safe_ip(hostname: str) -> str | None:
    """Resolve *hostname* to a validated public IP address.

    Resolves ALL A/AAAA records and rejects the hostname if **any** record
    points to a private, loopback, link-local, reserved, or multicast address.
    This is the second DNS-validation step recommended by the OWASP SSRF
    Prevention Cheat Sheet (Application Layer / Case 2) to close the
    DNS-rebinding window that exists when validation and connection use
    separate lookups.

    Returns the first resolved IP string on success, or ``None`` if the host
    is blocked or DNS resolution fails.
    """
    # Fast-path: explicit blocklist and prefix checks (no DNS query needed)
    if hostname in _BLOCKED_HOSTS or hostname.endswith(".local"):
        return None
    for prefix in ("10.", "192.168.", "172.16.", "172.17.", "172.18.", "172.19.",
                    "172.20.", "172.21.", "172.22.", "172.23.", "172.24.", "172.25.",
                    "172.26.", "172.27.", "172.28.", "172.29.", "172.30.", "172.31."):
        if hostname.startswith(prefix):
            return None

    try:
        addr_info = socket.getaddrinfo(hostname, None, socket.AF_UNSPEC, socket.SOCK_STREAM)
    except socket.gaierror:
        return None

    if not addr_info:
        return None

    first_safe_ip: str | None = None
    for _family, _type, _proto, _canonname, sockaddr in addr_info:
        ip_str = sockaddr[0]
        try:
            ip = ipaddress.ip_address(ip_str)
        except ValueError:
            return None  # Malformed address — reject entirely
        if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved or ip.is_multicast:
            return None  # Any private record → block the whole hostname
        if first_safe_ip is None:
            first_safe_ip = ip_str

    return first_safe_ip


def _make_pinned_request(url: str, resolved_ip: str, hostname: str, timeout: int = 15):
    """Make an HTTP request with DNS **pinned** to *resolved_ip*.

    Temporarily overrides ``socket.getaddrinfo`` for *hostname* so that the
    underlying TCP connection goes to the already-validated IP address rather
    than performing a fresh DNS lookup.  This closes the DNS-rebinding attack
    window (CWE-918) that would otherwise exist between ``_resolve_safe_ip``
    and the actual ``requests.get`` call.

    For HTTPS the original *hostname* remains in the URL, so TLS certificate
    verification and SNI still use the correct hostname — only the OS-level
    address resolution is pinned.

    The ``_dns_pin_lock`` serialises all URL fetches so the global
    ``socket.getaddrinfo`` override is never visible to other threads.
    """
    with _dns_pin_lock:
        _orig_getaddrinfo = socket.getaddrinfo

        def _pinned_getaddrinfo(host, port, *args, **kwargs):
            if host == hostname:
                family = socket.AF_INET6 if ":" in resolved_ip else socket.AF_INET
                return [(family, socket.SOCK_STREAM, 0, "", (resolved_ip, port or 0))]
            return _orig_getaddrinfo(host, port, *args, **kwargs)

        socket.getaddrinfo = _pinned_getaddrinfo
        try:
            return req_lib.get(url, timeout=timeout, allow_redirects=False, headers={
                "User-Agent": "FrictionBreaker/1.0 (OSINT research tool)"
            })
        finally:
            socket.getaddrinfo = _orig_getaddrinfo


def _strip_html(text: str) -> str:
    """Remove HTML tags and normalize whitespace using the standard library parser."""
    from html.parser import HTMLParser

    class _TextExtractor(HTMLParser):
        def __init__(self):
            super().__init__()
            self._pieces: list[str] = []
            self._skip = False

        def handle_starttag(self, tag, attrs):
            if tag in ("script", "style"):
                self._skip = True

        def handle_endtag(self, tag):
            if tag in ("script", "style"):
                self._skip = False

        def handle_data(self, data):
            if not self._skip:
                self._pieces.append(data)

    parser = _TextExtractor()
    parser.feed(text)
    combined = " ".join(parser._pieces)
    return _RE_WHITESPACE.sub(" ", combined).strip()


_MAX_REDIRECTS = 5


def _validate_url(url: str) -> str | None:
    """Validate a URL's scheme and hostname. Returns the safe URL or None."""
    parsed = urlparse(url)
    hostname = (parsed.hostname or "").lower()
    if _is_private_host(hostname):
        logger.warning("Blocked request to private/internal address")
        return None
    if parsed.scheme not in ("http", "https"):
        logger.warning("Blocked request with non-HTTP scheme")
        return None
    safe_url = f"{parsed.scheme}://{parsed.netloc}{parsed.path}"
    if parsed.query:
        safe_url += f"?{parsed.query}"
    return safe_url


def fetch_url(url: str) -> str:
    """Fetch text content from a URL. Blocks private/internal addresses.

    Follows redirects (up to ``_MAX_REDIRECTS`` hops) while re-validating
    each intermediate destination against the SSRF blocklist.

    DNS-rebinding defence (OWASP SSRF Prevention, Application Layer, Case 2):
    After the blocklist check, ``_resolve_safe_ip`` resolves *all* DNS records
    and validates every IP before the request is dispatched.
    ``_make_pinned_request`` then pins the underlying TCP connection to that
    validated IP so a racing DNS response change cannot redirect traffic to an
    internal host.
    """
    if not _HAS_REQUESTS:
        return ""
    try:
        current_url = url
        for _hop in range(_MAX_REDIRECTS + 1):
            safe_url = _validate_url(current_url)
            if safe_url is None:
                return ""

            # Second-pass DNS resolution: validate all records and obtain the
            # IP that will be pinned for the actual TCP connection.
            parsed = urlparse(safe_url)
            hostname = (parsed.hostname or "").lower()
            safe_ip = _resolve_safe_ip(hostname)
            if safe_ip is None:
                logger.warning("Blocked request: no safe IP resolved for host")
                return ""

            resp = _make_pinned_request(safe_url, safe_ip, hostname)

            if resp.status_code in (301, 302, 303, 307, 308):
                location = resp.headers.get("Location", "")
                if not location:
                    logger.warning("Redirect with no Location header")
                    return ""
                current_url = location
                continue

            resp.raise_for_status()
            text = _strip_html(resp.text)
            return text[:_MAX_INPUT_CHARS]

        logger.warning("Too many redirects")
        return ""
    except Exception as e:
        logger.warning(f"URL fetch failed: {_sanitize_for_log(e)}")
        return ""


# ─── Save results ─────────────────────────────────────────────────────────────
def save_result(result: dict) -> Path:
    """Save analysis result to output/ directory as JSON and Markdown."""
    _OUTPUT_DIR.mkdir(exist_ok=True)
    ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")

    # Save JSON
    json_path = _OUTPUT_DIR / f"analysis_{ts}.json"
    with open(json_path, "w") as f:
        json.dump(result, f, indent=2)
    logger.info(f"Result saved: {json_path}")

    # Save Markdown report
    md_path = _OUTPUT_DIR / f"analysis_{ts}.md"
    md_path.write_text(_result_to_markdown(result))
    logger.info(f"Markdown report saved: {md_path}")

    return json_path


def _result_to_markdown(result: dict) -> str:
    """Convert an analysis result dict to a human-readable Markdown report."""
    lines: list[str] = []
    meta = result.get("_meta", {})
    ts = meta.get("timestamp", datetime.now(timezone.utc).isoformat())
    lines.append("# Friction Breaker — Countermeasure Report\n")
    lines.append(f"*Generated {ts}*\n")

    # Input summary
    if result.get("input_summary"):
        lines.append("## Input Summary\n")
        lines.append(f"{result['input_summary']}\n")

    # Plain-English summary
    if result.get("political_translator_summary"):
        lines.append("## What This Means (Plain English)\n")
        lines.append(f"{result['political_translator_summary']}\n")

    # Mechanisms identified
    mechanisms = result.get("mechanisms_identified", [])
    if mechanisms:
        lines.append("## Mechanisms Identified\n")
        for m in mechanisms:
            conf = m.get("confidence", "?")
            dur = m.get("durability", "?")
            lines.append(f"### {m.get('taxonomy_id', '?')} — {m.get('name', 'Unknown')}\n")
            lines.append(f"**Confidence:** {conf} · **Durability:** {dur}/10\n")
            if m.get("what_it_does"):
                lines.append(f"{m['what_it_does']}\n")
            if m.get("evidence"):
                lines.append(f"> *Evidence:* {m['evidence']}\n")
            cms = m.get("countermeasures", [])
            if cms:
                lines.append("#### Countermeasures\n")
                for c in cms:
                    lines.append(
                        f"- **{c.get('action', '')}** "
                        f"(durability {c.get('durability_score', '?')}/10, "
                        f"feasibility {c.get('feasibility', '?')})\n"
                        f"  - *Who can do it:* {c.get('who_can_do_it', '?')}\n"
                        f"  - {c.get('plain_english', '')}\n"
                    )

    # New mechanisms
    new_mechs = result.get("new_mechanisms_detected", [])
    if new_mechs:
        lines.append("## New Mechanisms Detected (Not in Taxonomy)\n")
        for nm in new_mechs:
            lines.append(
                f"- **{nm.get('name', '')}** "
                f"(category {nm.get('suggested_category', '?')}, "
                f"durability {nm.get('suggested_durability', '?')}/10)\n"
                f"  - {nm.get('description', '')}\n"
                f"  - *Why it matters:* {nm.get('why_it_matters', '')}\n"
            )

    # Metadata footer
    if meta:
        lines.append("---\n")
        lines.append(
            f"*Entities extracted: {meta.get('gliner_entities_extracted', 0)} · "
            f"Taxonomy: {meta.get('taxonomy_mechanisms_available', 0)} mechanisms · "
            f"Model: {meta.get('model', '?')} · "
            f"Processing time: {meta.get('processing_time_seconds', '?')}s*\n"
        )

    return "\n".join(lines)


# ─── Export: Plain Text ───────────────────────────────────────────────────────
def _result_to_text(result: dict) -> str:
    """Convert an analysis result dict to a plain-text report."""
    lines: list[str] = []
    meta = result.get("_meta", {})
    ts = meta.get("timestamp", datetime.now(timezone.utc).isoformat())
    lines.append("FRICTION BREAKER — COUNTERMEASURE REPORT")
    lines.append(f"Generated {ts}")
    lines.append("=" * 60)

    if result.get("input_summary"):
        lines.append("")
        lines.append("INPUT SUMMARY")
        lines.append("-" * 40)
        lines.append(result["input_summary"])

    if result.get("political_translator_summary"):
        lines.append("")
        lines.append("WHAT THIS MEANS (PLAIN ENGLISH)")
        lines.append("-" * 40)
        lines.append(result["political_translator_summary"])

    mechanisms = result.get("mechanisms_identified", [])
    if mechanisms:
        lines.append("")
        lines.append("MECHANISMS IDENTIFIED")
        lines.append("-" * 40)
        for m in mechanisms:
            lines.append("")
            lines.append(f"  [{m.get('taxonomy_id', '?')}] {m.get('name', 'Unknown')}")
            lines.append(f"  Confidence: {m.get('confidence', '?')}  |  Durability: {m.get('durability', '?')}/10")
            if m.get("what_it_does"):
                lines.append(f"  {m['what_it_does']}")
            if m.get("evidence"):
                lines.append(f"  Evidence: {m['evidence']}")
            cms = m.get("countermeasures", [])
            if cms:
                lines.append("  Countermeasures:")
                for c in cms:
                    lines.append(f"    * {c.get('action', '')}")
                    lines.append(f"      Durability: {c.get('durability_score', '?')}/10  "
                                 f"Feasibility: {c.get('feasibility', '?')}")
                    lines.append(f"      Who: {c.get('who_can_do_it', '?')}")
                    lines.append(f"      {c.get('plain_english', '')}")

    new_mechs = result.get("new_mechanisms_detected", [])
    if new_mechs:
        lines.append("")
        lines.append("NEW MECHANISMS DETECTED (NOT IN TAXONOMY)")
        lines.append("-" * 40)
        for nm in new_mechs:
            lines.append(f"  * {nm.get('name', '')} "
                         f"(category {nm.get('suggested_category', '?')}, "
                         f"durability {nm.get('suggested_durability', '?')}/10)")
            lines.append(f"    {nm.get('description', '')}")
            lines.append(f"    Why it matters: {nm.get('why_it_matters', '')}")

    if meta:
        lines.append("")
        lines.append("-" * 60)
        lines.append(f"Entities extracted: {meta.get('gliner_entities_extracted', 0)} | "
                     f"Taxonomy: {meta.get('taxonomy_mechanisms_available', 0)} mechanisms | "
                     f"Model: {meta.get('model', '?')} | "
                     f"Processing time: {meta.get('processing_time_seconds', '?')}s")

    return "\n".join(lines)


# ─── Export: CSV ──────────────────────────────────────────────────────────────
def _result_to_csv(result: dict) -> str:
    """Convert mechanisms from an analysis result to CSV format."""
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow([
        "Taxonomy ID", "Mechanism Name", "Confidence", "Durability",
        "What It Does", "Evidence",
        "Countermeasure", "CM Durability", "CM Feasibility",
        "Who Can Do It", "Plain English",
    ])
    for m in result.get("mechanisms_identified", []):
        cms = m.get("countermeasures", [])
        if cms:
            for c in cms:
                writer.writerow([
                    m.get("taxonomy_id", ""),
                    m.get("name", ""),
                    m.get("confidence", ""),
                    m.get("durability", ""),
                    m.get("what_it_does", ""),
                    m.get("evidence", ""),
                    c.get("action", ""),
                    c.get("durability_score", ""),
                    c.get("feasibility", ""),
                    c.get("who_can_do_it", ""),
                    c.get("plain_english", ""),
                ])
        else:
            writer.writerow([
                m.get("taxonomy_id", ""),
                m.get("name", ""),
                m.get("confidence", ""),
                m.get("durability", ""),
                m.get("what_it_does", ""),
                m.get("evidence", ""),
                "", "", "", "", "",
            ])
    return output.getvalue()


# ─── Export: DOCX ─────────────────────────────────────────────────────────────
def _result_to_docx(result: dict) -> bytes:
    """Convert an analysis result dict to a DOCX document (returned as bytes)."""
    if not _HAS_DOCX:
        raise RuntimeError("python-docx is not installed")

    doc = DocxDocument()

    # Title
    title = doc.add_heading("Friction Breaker — Countermeasure Report", level=0)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER

    meta = result.get("_meta", {})
    ts = meta.get("timestamp", datetime.now(timezone.utc).isoformat())
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run(f"Generated {ts}")
    run.font.size = Pt(9)
    run.font.color.rgb = RGBColor(0x66, 0x66, 0x66)

    # Input summary
    if result.get("input_summary"):
        doc.add_heading("Input Summary", level=1)
        doc.add_paragraph(result["input_summary"])

    # Plain-English summary
    if result.get("political_translator_summary"):
        doc.add_heading("What This Means (Plain English)", level=1)
        doc.add_paragraph(result["political_translator_summary"])

    # Mechanisms
    mechanisms = result.get("mechanisms_identified", [])
    if mechanisms:
        doc.add_heading("Mechanisms Identified", level=1)
        for m in mechanisms:
            doc.add_heading(
                f"{m.get('taxonomy_id', '?')} — {m.get('name', 'Unknown')}", level=2
            )
            p = doc.add_paragraph()
            p.add_run("Confidence: ").bold = True
            p.add_run(f"{m.get('confidence', '?')}  |  ")
            p.add_run("Durability: ").bold = True
            p.add_run(f"{m.get('durability', '?')}/10")

            if m.get("what_it_does"):
                doc.add_paragraph(m["what_it_does"])
            if m.get("evidence"):
                p = doc.add_paragraph()
                p.add_run("Evidence: ").bold = True
                p.add_run(m["evidence"]).italic = True

            cms = m.get("countermeasures", [])
            if cms:
                doc.add_heading("Countermeasures", level=3)
                for c in cms:
                    p = doc.add_paragraph(style="List Bullet")
                    p.add_run(c.get("action", "")).bold = True
                    p.add_run(f"  (durability {c.get('durability_score', '?')}/10, "
                              f"feasibility {c.get('feasibility', '?')})")
                    sub = doc.add_paragraph(style="List Bullet 2")
                    sub.add_run("Who can do it: ").bold = True
                    sub.add_run(c.get("who_can_do_it", "?"))
                    sub2 = doc.add_paragraph(style="List Bullet 2")
                    sub2.add_run(c.get("plain_english", ""))

    # New mechanisms
    new_mechs = result.get("new_mechanisms_detected", [])
    if new_mechs:
        doc.add_heading("New Mechanisms Detected (Not in Taxonomy)", level=1)
        for nm in new_mechs:
            p = doc.add_paragraph(style="List Bullet")
            p.add_run(nm.get("name", "")).bold = True
            p.add_run(f"  (category {nm.get('suggested_category', '?')}, "
                      f"durability {nm.get('suggested_durability', '?')}/10)")
            doc.add_paragraph(nm.get("description", ""))
            p = doc.add_paragraph()
            p.add_run("Why it matters: ").italic = True
            p.add_run(nm.get("why_it_matters", ""))

    # Metadata footer
    if meta:
        doc.add_paragraph("")  # spacer
        p = doc.add_paragraph()
        run = p.add_run(
            f"Entities extracted: {meta.get('gliner_entities_extracted', 0)} · "
            f"Taxonomy: {meta.get('taxonomy_mechanisms_available', 0)} mechanisms · "
            f"Model: {meta.get('model', '?')} · "
            f"Processing time: {meta.get('processing_time_seconds', '?')}s"
        )
        run.font.size = Pt(8)
        run.font.color.rgb = RGBColor(0x99, 0x99, 0x99)

    buf = io.BytesIO()
    doc.save(buf)
    return buf.getvalue()


# ─── Export: PDF ──────────────────────────────────────────────────────────────
def _result_to_pdf(result: dict) -> bytes:
    """Convert an analysis result dict to a PDF document (returned as bytes)."""
    if not _HAS_REPORTLAB:
        raise RuntimeError("reportlab is not installed")

    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=letter,
                            leftMargin=0.75 * inch, rightMargin=0.75 * inch,
                            topMargin=0.75 * inch, bottomMargin=0.75 * inch)
    styles = getSampleStyleSheet()

    # Custom styles
    title_style = ParagraphStyle("ReportTitle", parent=styles["Title"], fontSize=20,
                                 spaceAfter=4, textColor=colors.HexColor("#1a1a2e"))
    subtitle_style = ParagraphStyle("ReportSubtitle", parent=styles["Normal"], fontSize=9,
                                    textColor=colors.grey, alignment=1, spaceAfter=16)
    heading1_style = ParagraphStyle("H1", parent=styles["Heading1"], fontSize=14,
                                    textColor=colors.HexColor("#2d3436"), spaceBefore=16, spaceAfter=8)
    heading2_style = ParagraphStyle("H2", parent=styles["Heading2"], fontSize=12,
                                    textColor=colors.HexColor("#0984e3"), spaceBefore=12, spaceAfter=6)
    heading3_style = ParagraphStyle("H3", parent=styles["Heading3"], fontSize=10,
                                    textColor=colors.HexColor("#00b894"), spaceBefore=8, spaceAfter=4)
    body_style = ParagraphStyle("Body", parent=styles["Normal"], fontSize=10,
                                leading=14, spaceAfter=6)
    evidence_style = ParagraphStyle("Evidence", parent=styles["Normal"], fontSize=9,
                                    leftIndent=20, textColor=colors.HexColor("#636e72"),
                                    fontName="Helvetica-Oblique", spaceAfter=6)
    bullet_style = ParagraphStyle("Bullet", parent=styles["Normal"], fontSize=10,
                                  leftIndent=24, bulletIndent=12, spaceAfter=4, leading=13)
    meta_style = ParagraphStyle("Meta", parent=styles["Normal"], fontSize=8,
                                textColor=colors.grey, spaceBefore=20)

    story: list = []
    meta = result.get("_meta", {})
    ts = meta.get("timestamp", datetime.now(timezone.utc).isoformat())

    story.append(Paragraph("Friction Breaker — Countermeasure Report", title_style))
    story.append(Paragraph(f"Generated {ts}", subtitle_style))

    if result.get("input_summary"):
        story.append(Paragraph("Input Summary", heading1_style))
        story.append(Paragraph(result["input_summary"], body_style))

    if result.get("political_translator_summary"):
        story.append(Paragraph("What This Means (Plain English)", heading1_style))
        # Split paragraphs for readability
        for para in result["political_translator_summary"].split("\n"):
            if para.strip():
                story.append(Paragraph(para.strip(), body_style))

    mechanisms = result.get("mechanisms_identified", [])
    if mechanisms:
        story.append(Paragraph("Mechanisms Identified", heading1_style))
        for m in mechanisms:
            tid = m.get("taxonomy_id", "?")
            name = m.get("name", "Unknown")
            story.append(Paragraph(f"{tid} — {name}", heading2_style))
            story.append(Paragraph(
                f"<b>Confidence:</b> {m.get('confidence', '?')} · "
                f"<b>Durability:</b> {m.get('durability', '?')}/10",
                body_style
            ))
            if m.get("what_it_does"):
                story.append(Paragraph(m["what_it_does"], body_style))
            if m.get("evidence"):
                story.append(Paragraph(f"Evidence: {m['evidence']}", evidence_style))

            cms = m.get("countermeasures", [])
            if cms:
                story.append(Paragraph("Countermeasures", heading3_style))
                for c in cms:
                    action = c.get("action", "")
                    story.append(Paragraph(
                        f"<b>• {action}</b>  "
                        f"(durability {c.get('durability_score', '?')}/10, "
                        f"feasibility {c.get('feasibility', '?')})",
                        bullet_style
                    ))
                    story.append(Paragraph(
                        f"<b>Who:</b> {c.get('who_can_do_it', '?')} — "
                        f"{c.get('plain_english', '')}",
                        bullet_style
                    ))

    new_mechs = result.get("new_mechanisms_detected", [])
    if new_mechs:
        story.append(Paragraph("New Mechanisms Detected (Not in Taxonomy)", heading1_style))
        for nm in new_mechs:
            story.append(Paragraph(
                f"<b>{nm.get('name', '')}</b>  "
                f"(category {nm.get('suggested_category', '?')}, "
                f"durability {nm.get('suggested_durability', '?')}/10)",
                body_style
            ))
            story.append(Paragraph(nm.get("description", ""), body_style))
            if nm.get("why_it_matters"):
                story.append(Paragraph(
                    f"<i>Why it matters:</i> {nm['why_it_matters']}", body_style
                ))

    if meta:
        story.append(Spacer(1, 20))
        story.append(Paragraph(
            f"Entities extracted: {meta.get('gliner_entities_extracted', 0)} · "
            f"Taxonomy: {meta.get('taxonomy_mechanisms_available', 0)} mechanisms · "
            f"Model: {meta.get('model', '?')} · "
            f"Processing time: {meta.get('processing_time_seconds', '?')}s",
            meta_style
        ))

    doc.build(story)
    return buf.getvalue()


# ─── Export dispatcher ────────────────────────────────────────────────────────
_EXPORT_FORMATS = {
    "pdf": {"content_type": "application/pdf", "ext": ".pdf"},
    "docx": {"content_type": "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "ext": ".docx"},
    "markdown": {"content_type": "text/markdown; charset=utf-8", "ext": ".md"},
    "csv": {"content_type": "text/csv; charset=utf-8", "ext": ".csv"},
    "json": {"content_type": "application/json; charset=utf-8", "ext": ".json"},
    "text": {"content_type": "text/plain; charset=utf-8", "ext": ".txt"},
}


def export_result(result: dict, fmt: str) -> tuple[bytes, str, str]:
    """Export an analysis result in the requested format.

    Returns ``(file_bytes, content_type, filename)``.
    Raises ``ValueError`` for unsupported formats and ``RuntimeError`` when
    a required library is missing.

    Security note: Export content is user-controlled and must not be
    HTML-escaped — that transform is only valid in an HTML rendering
    context and corrupts JSON/CSV/TXT/Markdown/PDF/DOCX output.
    Anti-execution protection is handled via response headers
    (Content-Disposition: attachment, Content-Security-Policy: sandbox,
    X-Content-Type-Options: nosniff, etc.) set by the /export endpoint.
    """
    if fmt not in _EXPORT_FORMATS:
        raise ValueError(f"Unsupported export format: {fmt}")

    info = _EXPORT_FORMATS[fmt]
    ts = (result.get("_meta", {}).get("timestamp") or datetime.now(timezone.utc).isoformat())
    safe_ts = re.sub(r"[^A-Za-z0-9_]", "", ts.replace(":", "").replace("-", "").replace("T", "_").split(".")[0])
    if not safe_ts:
        safe_ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    filename = f"friction_breaker_report_{safe_ts}{info['ext']}"

    if fmt == "pdf":
        data = _result_to_pdf(result)
    elif fmt == "docx":
        data = _result_to_docx(result)
    elif fmt == "markdown":
        data = _result_to_markdown(result).encode("utf-8")
    elif fmt == "csv":
        data = _result_to_csv(result).encode("utf-8")
    elif fmt == "json":
        data = json.dumps(result, indent=2).encode("utf-8")
    elif fmt == "text":
        data = _result_to_text(result).encode("utf-8")
    else:
        raise ValueError(f"Unsupported export format: {fmt}")

    return data, info["content_type"], filename


# ─── Full analysis pipeline ───────────────────────────────────────────────────
def run_analysis(text: str, api_key: str) -> dict:
    """Run the full Friction Breaker pipeline on input text."""
    start = time.time()

    # 1. Load taxonomy
    taxonomy = load_taxonomy()
    if not taxonomy.get("mechanisms"):
        return {"error": "Taxonomy not loaded. Ensure mechanism_classifier_taxonomy.json exists."}

    # 2. Load context index
    context_index = load_context_index()

    # 3. Extract entities (GLiNER2, local, zero-cost)
    logger.info("Extracting entities with GLiNER2...")
    entities = extract_entities_gliner(text)
    logger.info(f"Extracted {len(entities)} entities.")

    # 4. Classify and analyze (Claude API)
    logger.info("Sending to Claude for mechanism classification + countermeasure analysis...")
    result = analyze_with_claude(text, entities, taxonomy, context_index, api_key)

    # 5. Add metadata
    result["_meta"] = {
        "gliner_entities_extracted": len(entities),
        "gliner_entities": entities[:20],
        "taxonomy_version": taxonomy.get("metadata", {}).get("version"),
        "taxonomy_mechanisms_available": len(taxonomy.get("mechanisms", [])),
        "context_index_loaded": bool(context_index),
        "processing_time_seconds": round(time.time() - start, 2),
        "model": _ANTHROPIC_MODEL,
        "timestamp": datetime.now(timezone.utc).isoformat()
    }

    # 6. Save
    save_result(result)

    return result


# ─── Flask App ────────────────────────────────────────────────────────────────
def create_app():
    app = Flask(__name__)

    # Rate limiting — protects against quota exhaustion on /analyze
    if _HAS_LIMITER:
        limiter = Limiter(
            get_remote_address,
            app=app,
            default_limits=[],
            storage_uri="memory://",
        )

        @app.errorhandler(429)
        def rate_limit_handler(e):
            return jsonify({"error": "Rate limit exceeded. Please wait before trying again."}), 429
    else:
        limiter = None

    @app.route("/")
    def index():
        return render_template("index.html")

    @app.after_request
    def add_security_headers(response):
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        response.headers.setdefault("X-Frame-Options", "DENY")
        response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
        # Cross-origin isolation (OWASP HTTP Headers Cheat Sheet, 2026)
        response.headers.setdefault("Cross-Origin-Opener-Policy", "same-origin")
        response.headers.setdefault("Cross-Origin-Resource-Policy", "same-site")
        # Restrict access to browser features (Permissions-Policy replaces Feature-Policy)
        response.headers.setdefault(
            "Permissions-Policy",
            "camera=(), microphone=(), geolocation=(), payment=(), usb=()"
        )
        # Content-Security-Policy for HTML responses only.
        # The /export endpoint sets its own sandbox CSP; skip HTML pages if
        # CSP is already present (e.g. set by export_result).
        content_type = response.headers.get("Content-Type", "")
        if "text/html" in content_type and "Content-Security-Policy" not in response.headers:
            # All scripts and styles are inline; no external resources are loaded.
            # 'unsafe-inline' is required because the single-page app embeds
            # <script> and <style> blocks directly in index.html.
            response.headers["Content-Security-Policy"] = (
                "default-src 'self'; "
                "script-src 'self' 'unsafe-inline'; "
                "style-src 'self' 'unsafe-inline'; "
                "img-src 'self' data:; "
                "connect-src 'self'; "
                "font-src 'self'; "
                "object-src 'none'; "
                "base-uri 'self'; "
                "form-action 'self'; "
                "frame-ancestors 'none'"
            )
        return response

    @app.errorhandler(500)
    def internal_error(e):
        logger.error(f"Internal server error: {e}")
        return jsonify({"error": "An unexpected server error occurred. Please try again."}), 500

    @app.route("/analyze", methods=["POST"])
    def analyze():  # Rate-limited to 10/min per IP when flask-limiter is available (applied below)
        data = request.get_json()
        if not data:
            return jsonify({"error": "No JSON body"}), 400

        api_key = data.get("api_key", "").strip()
        text = data.get("text", "").strip()
        url = data.get("url", "").strip()

        if not api_key:
            # Fall back to env var
            api_key = os.getenv("ANTHROPIC_API_KEY", "")
        if not api_key:
            return jsonify({"error": "No API key provided. Set ANTHROPIC_API_KEY or enter it in the form."}), 400

        # Get text from URL if provided
        if url and not text:
            text = fetch_url(url)
            if not text:
                return jsonify({"error": "Could not fetch content from the provided URL."}), 400

        if not text:
            return jsonify({"error": "No text provided. Paste text or provide a URL."}), 400

        if len(text) > _MAX_INPUT_CHARS:
            text = text[:_MAX_INPUT_CHARS]

        # Kick off analysis in a background thread so long-running Claude API
        # calls don't hit the 60-second reverse-proxy timeout in Codespaces /
        # other hosted environments.  The client polls /status/<job_id>.
        job_id = str(uuid.uuid4())
        with _jobs_lock:
            _jobs[job_id] = {"status": "pending", "result": None, "created_at": time.time()}
        thread = threading.Thread(target=_run_job_thread, args=(job_id, text, api_key), daemon=True)
        thread.start()
        return jsonify({"job_id": job_id, "status": "pending"}), 202

    # Apply rate limit to /analyze only (avoids interfering with health/taxonomy/index)
    if limiter is not None:
        analyze = limiter.limit(_RATE_LIMIT)(analyze)

    @app.route("/status/<job_id>", methods=["GET"])
    def job_status(job_id):
        """Poll the status of an async analysis job."""
        _cleanup_old_jobs()
        with _jobs_lock:
            job = _jobs.get(job_id)
        if not job:
            return jsonify({"error": "Job not found or expired."}), 404
        return jsonify({"status": job["status"], "result": job.get("result")})

    @app.route("/upload", methods=["POST"])
    def upload():
        """Extract plain text from an uploaded file (.txt, .md, .csv, .docx).

        Accepts multipart/form-data with a single 'file' field.
        Returns ``{"text": "<extracted content>"}`` on success.
        """
        uploaded = request.files.get("file")
        if not uploaded or not uploaded.filename:
            return jsonify({"error": "No file provided."}), 400

        filename = uploaded.filename.lower()

        # Validate file type before reading content
        if not filename.endswith((".txt", ".md", ".csv", ".docx")):
            return jsonify({"error": "Unsupported file type. Upload .txt, .md, .csv, or .docx files."}), 400

        try:
            if filename.endswith(".docx"):
                if not _HAS_DOCX:
                    return jsonify({"error": "DOCX support not available on this server."}), 501
                doc = DocxDocument(uploaded)
                text = "\n".join(para.text for para in doc.paragraphs)
            else:
                text = uploaded.read().decode("utf-8", errors="replace")
        except Exception as exc:
            logger.error(f"File upload extraction failed: {exc}")
            return jsonify({"error": "Could not extract text from the uploaded file."}), 500

        text = text.strip()
        if not text:
            return jsonify({"error": "The uploaded file appears to be empty."}), 400
        if len(text) > _MAX_INPUT_CHARS:
            text = text[:_MAX_INPUT_CHARS]
        return jsonify({"text": text})

    @app.route("/taxonomy")
    def taxonomy_view():
        taxonomy = load_taxonomy()
        return jsonify(taxonomy)

    @app.route("/export", methods=["POST"])
    def export():
        """Export analysis results in the requested format (pdf, docx, markdown, csv, json, text)."""
        data = request.get_json()
        if not data:
            return jsonify({"error": "No JSON body"}), 400

        fmt = data.get("format", "").strip().lower()
        result = data.get("result")

        if not fmt:
            return jsonify({"error": "Missing 'format' parameter."}), 400
        if fmt not in _EXPORT_FORMATS:
            return jsonify({
                "error": f"Unsupported format: {fmt}. Supported: {', '.join(sorted(_EXPORT_FORMATS))}",
            }), 400
        if not result or not isinstance(result, dict):
            return jsonify({"error": "Missing or invalid 'result' object."}), 400

        try:
            file_bytes, content_type, filename = export_result(result, fmt)
        except RuntimeError:
            return jsonify({"error": "A required export library is not installed on the server."}), 501
        except Exception as exc:
            logger.error(f"Export error: {exc}")
            return jsonify({"error": "An error occurred while generating the export."}), 500

        resp = make_response(file_bytes)
        resp.headers["Content-Type"] = content_type
        # Use RFC 5987 dual-param encoding: ASCII fallback + full UTF-8 encoded name
        ascii_name = urlquote(filename, safe="-_.")
        utf8_name = urlquote(filename, safe="")
        resp.headers["Content-Disposition"] = f"attachment; filename=\"{ascii_name}\"; filename*=UTF-8''{utf8_name}"
        resp.headers["Content-Transfer-Encoding"] = "binary"
        resp.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, private"
        resp.headers["Pragma"] = "no-cache"
        resp.headers["Expires"] = "0"
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["X-Frame-Options"] = "DENY"
        resp.headers["Referrer-Policy"] = "no-referrer"
        # Defense-in-depth for reflected user-controlled export payloads.
        # If a browser attempts to render the response, sandbox it completely
        # to block script execution and all active content.
        resp.headers["Content-Security-Policy"] = "sandbox; default-src 'none'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'"
        resp.headers["Cross-Origin-Resource-Policy"] = "same-origin"
        resp.headers["Cross-Origin-Opener-Policy"] = "same-origin"
        resp.headers["X-Download-Options"] = "noopen"
        return resp

    @app.route("/health")
    def health():
        taxonomy = load_taxonomy()
        return jsonify({
            "status": "ok",
            "gliner_available": _HAS_GLINER,
            "anthropic_available": _HAS_ANTHROPIC,
            "taxonomy_loaded": _TAXONOMY_FILE.exists(),
            "taxonomy_version": taxonomy.get("metadata", {}).get("version"),
            "context_index_loaded": _CONTEXT_DIR.exists()
        })

    return app


# ─── CLI Mode ─────────────────────────────────────────────────────────────────
def cli_analyze(text: str):
    """Run analysis from command line."""
    api_key = os.getenv("ANTHROPIC_API_KEY", "")
    if not api_key:
        logger.error("ANTHROPIC_API_KEY not set. Add it to .env or export it.")
        sys.exit(1)
    result = run_analysis(text, api_key)
    print(json.dumps(result, indent=2))


def cli_batch(batch_path: str):
    """Process a batch file containing one URL or text per line."""
    api_key = os.getenv("ANTHROPIC_API_KEY", "")
    if not api_key:
        logger.error("ANTHROPIC_API_KEY not set. Add it to .env or export it.")
        sys.exit(1)

    path = Path(batch_path)
    if not path.exists():
        logger.error(f"Batch file not found: {batch_path}")
        sys.exit(1)

    lines = [ln.strip() for ln in path.read_text().splitlines() if ln.strip() and not ln.strip().startswith("#")]
    if not lines:
        logger.error("Batch file is empty or contains only comments.")
        sys.exit(1)

    logger.info(f"Batch mode: {len(lines)} items to process.")
    for idx, line in enumerate(lines, 1):
        logger.info(f"[{idx}/{len(lines)}] Processing: {line[:80]}{'...' if len(line) > 80 else ''}")
        # Determine if the line is a URL or raw text
        text = line
        if line.startswith("http://") or line.startswith("https://"):
            text = fetch_url(line)
            if not text:
                logger.warning(f"[{idx}/{len(lines)}] Could not fetch URL, skipping: {line}")
                continue
        result = run_analysis(text, api_key)
        if "error" in result:
            logger.warning(f"[{idx}/{len(lines)}] Analysis error: {result['error']}")
        else:
            logger.info(f"[{idx}/{len(lines)}] Done.")
    logger.info("Batch processing complete. Results saved to output/.")


# ─── Main ─────────────────────────────────────────────────────────────────────
def main():
    """Entry point for both ``python app.py`` and the ``friction-breaker`` console script."""
    parser = argparse.ArgumentParser(description="Friction Breaker — Countermeasure Engine")
    parser.add_argument("--port", type=int, default=5000, help="Flask server port")
    parser.add_argument("--analyze", type=str, help="Analyze text directly (CLI mode)")
    parser.add_argument("--url", type=str, help="Fetch and analyze a URL (CLI mode)")
    parser.add_argument(
        "--batch",
        type=str,
        help="Path to a file containing one URL or text per line. Results saved to output/.",
    )
    args = parser.parse_args()

    if args.batch:
        cli_batch(args.batch)
    elif args.analyze:
        cli_analyze(args.analyze)
    elif args.url:
        text = fetch_url(args.url)
        if text:
            cli_analyze(text)
        else:
            logger.error(f"Could not fetch URL: {args.url}")
    else:
        if not _HAS_FLASK:
            logger.error("Flask not installed. Install it: pip install flask")
            sys.exit(1)
        app = create_app()
        print(f"\n🔧 Friction Breaker running on http://{_FLASK_HOST}:{args.port}")
        print(f"   Taxonomy: {len(load_taxonomy().get('mechanisms', []))} mechanisms loaded")
        print(f"   GLiNER2: {'available' if _load_gliner() else 'not available (Claude-only mode)'}")
        print("   BYOK: Enter your ANTHROPIC_API_KEY in the web interface\n")
        app.run(host=_FLASK_HOST, port=args.port, debug=False)


if __name__ == "__main__":
    main()
